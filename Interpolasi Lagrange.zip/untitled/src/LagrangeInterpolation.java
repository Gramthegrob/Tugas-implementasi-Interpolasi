import java.util.Scanner;

public class LagrangeInterpolation {
    public static void main(String[] args) {
        // Data input
        double[] x = {5, 10, 15, 20, 25, 30, 35, 40};
        double[] y = {40, 30, 25, 40, 18, 20, 22, 15};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nilai x yang akan diinterpolasi: ");
        double xi = scanner.nextDouble();

        double yi = lagrangeInterpolation(x, y, xi);
        System.out.println("Nilai y yang diinterpolasi pada x = " + xi + " adalah " + yi);

        scanner.close();
    }

    public static double lagrangeInterpolation(double[] x, double[] y, double xi) {
        double result = 0.0;
        int n = x.length;

        for (int i = 0; i < n; i++) {
            double term = y[i];
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    term *= (xi - x[j]) / (x[i] - x[j]);
                }
            }
            result += term;
        }

        return result;
    }
}
