public class NewtonInterpolationTest {
    public static void main(String[] args) {
        // Data input
        double[] x = {5, 10, 15, 20, 25, 30, 35, 40};
        double[] y = {40, 30, 25, 40, 18, 20, 22, 15};

        // Test cases
        double[] testX = {12, 28, 33};
        double[] expectedY = {0, 0, 0}; // Replace with expected values if known

        for (int i = 0; i < testX.length; i++) {
            double interpolatedY = newtonInterpolation(x, y, testX[i]);
            System.out.println("x: " + testX[i] + ", Interpolated y: " + interpolatedY + ", Expected y: " + expectedY[i]);
        }
    }

    public static double newtonInterpolation(double[] x, double[] y, double xi) {
        int n = x.length;
        double[] dividedDifference = new double[n];

        // Initialize divided difference array with y values
        for (int i = 0; i < n; i++) {
            dividedDifference[i] = y[i];
        }

        // Compute the divided differences
        for (int i = 1; i < n; i++) {
            for (int j = n - 1; j >= i; j--) {
                dividedDifference[j] = (dividedDifference[j] - dividedDifference[j - i]) / (x[j] - x[j - i]);
            }
        }

        // Interpolate the value at xi
        double result = dividedDifference[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            result = result * (xi - x[i]) + dividedDifference[i];
        }

        return result;
    }
}
