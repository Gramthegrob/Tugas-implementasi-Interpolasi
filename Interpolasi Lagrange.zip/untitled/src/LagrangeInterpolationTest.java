public class LagrangeInterpolationTest {
    public static void main(String[] args) {
        // Data input
        double[] x = {5, 10, 15, 20, 25, 30, 35, 40};
        double[] y = {40, 30, 25, 40, 18, 20, 22, 15};

        // Test cases
        double[] testX = {12, 28, 33};
        double[] expectedY = {0, 0, 0}; // Replace with expected values if known

        for (int i = 0; i < testX.length; i++) {
            double interpolatedY = lagrangeInterpolation(x, y, testX[i]);
            System.out.println("x: " + testX[i] + ", Interpolated y: " + interpolatedY + ", Expected y: " + expectedY[i]);
        }
    }

    public static double lagrangeInterpolation(double[] x, double[] y, double xi) {
        double result = 0.0;
        int n = x.length;

        for (int i = 0; i < n; i++) {
            double term = y[i];
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    term *= (xi - x[j]) / (x[i] - x[j]);
                }
            }
            result += term;
        }

        return result;
    }
}
