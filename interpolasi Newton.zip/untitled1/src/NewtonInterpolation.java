import java.util.Scanner;

public class NewtonInterpolation {
    public static void main(String[] args) {
        // Data input
        double[] x = {5, 10, 15, 20, 25, 30, 35, 40};
        double[] y = {40, 30, 25, 40, 18, 20, 22, 15};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nilai x yang akan diinterpolasi: ");
        double xi = scanner.nextDouble();

        double yi = newtonInterpolation(x, y, xi);
        System.out.println("Nilai y yang diinterpolasi pada x = " + xi + " adalah " + yi);

        scanner.close();
    }

    public static double newtonInterpolation(double[] x, double[] y, double xi) {
        int n = x.length;
        double[] dividedDifference = new double[n];

        // Initialize divided difference array with y values
        for (int i = 0; i < n; i++) {
            dividedDifference[i] = y[i];
        }

        // Compute the divided differences
        for (int i = 1; i < n; i++) {
            for (int j = n - 1; j >= i; j--) {
                dividedDifference[j] = (dividedDifference[j] - dividedDifference[j - i]) / (x[j] - x[j - i]);
            }
        }

        // Interpolate the value at xi
        double result = dividedDifference[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            result = result * (xi - x[i]) + dividedDifference[i];
        }

        return result;
    }
}
